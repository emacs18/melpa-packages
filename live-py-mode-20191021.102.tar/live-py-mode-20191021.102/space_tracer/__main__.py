from .code_tracer import main

main()
